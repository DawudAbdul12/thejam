




<!-- footer -->
<section class="fot pt-5  d-none d-lg-block">
  <div class="container">
    <div class="row">
      <div class="col-xl-3">
       <p class="wc"><strong>THINK MYI</strong></p>
       <p class="wc">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
       tempor incididunt ut labore et dolore magn</p>
     </div>
     <div class="col-xl-3">
      <p class="wc"><strong>WHAHT WE DO</strong></p>
      <p>
        <a href="#" class="wc">
        What We Do One</a><br>
        <a href="#" class="wc">What We Do Two</a><br>
        <a href="#" class="wc">What We Do Three</a>
      </p>
    </div>
    <div class="col-xl-3">
      <p class="wc"><strong>SOCIAL LINKS</strong></p>
      <p>
        <a href="#" class="wc">Facebook</a><br>
        <a href="#" class="wc">Twitter</a><br>
        <a href="#" class="wc">Instagram</a><br>
        <a href="#" class="wc">YouTube</a>
      </p>
    </div>
    <div class="col-xl-3">
      <p class="wc"><strong>CONTACT</strong></p>
      <p class="wc">No 24 Palace Street,
        <br> Dans-Bar Rd, North Kaneshie,</p>
        <p class="wc">Tel: +233 20-152-5252  / : +233 302260468  <br>Email: info@thimkmyi.com</p>

        <p>
         <a href="#" class="wc1f"> <i class="fa fa-facebook-official" aria-hidden="true"></i></a> 
         <span><a href="#" class="wc1f"> <i class="fa fa-twitter-square" aria-hidden="true"></i></a></span>
         <span><a href="#" class="wc1f"><i class="fa fa-linkedin " aria-hidden="true"></i></a></span>
       </p>
     </div>
   </div>
 </div>
</section>
<!-- footer -->


<div class="cx-mimi-foot  d-md-block d-lg-none">
  <div class="container">
    <div class="row centerit">
      <div class="col-4 text-center">
        <a href="index.php">
          <i class="fa fa-home fa-2x" aria-hidden="true"></i>
        </a>
      </div>



      <div class="col-4 text-center">
        <a href="">
          <img src="img/logogray.png" alt="" width="40">
        </a>
      </div>

      <div class="col-4 text-center">
        <a href="profile.php">
          <img src="img/user.png" alt="buy orders" width="40">
        </a>
      </div>
    </div>
  </div>
</div>


<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="js/jquery-3.3.1.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.js"></script>
<script src="plugins/lightbox2-master/dist/js/lightbox-plus-jquery.js"></script>

<!-- for date picker -->
<script type="text/javascript" src="plugins/datepicker/js/moment.min.js"></script>
<script type="text/javascript" src="plugins/datepicker/js/daterangepicker.js"></script>
<!-- for date picker -->
<script src="plugins/owlcarousel/owl.carousel.min.js" ></script>

<script src="js/app.js"></script>

<script>
$(function() {
  $('input[name="daterange"]').daterangepicker({
    opens: 'left'
  }, function(start, end, label) {
    console.log("A new date selection was made: " + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD'));
  });
});
</script>

<script src="plugins/wow/wow.min.js"></script>
<script>
  new WOW().init();
</script>
