<!doctype html>
<html lang="en">
<head>
  <title>The JAM</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="author" content="">
  <meta name="csrf-token" content="{{ csrf_token() }}" />
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

  <!-- include navigation -->
  @include('inc.navigation')
  <?php //require_once("includes/navigation.php");?>
  <!-- include navigation -->

  {{ Form::hidden('member_id',auth()->user()->id,['id'=>'member_id']) }}

   <!-- CONTENT -->
    @yield('content')

    <!-- CONTENT -->



<!-- footer includes -->
@include('inc.footer')
<?php //require_once("includes/footer.php");?>
<!-- footer includes -->

<script>
  function openNav() {
    document.getElementById("mySidenav").style.width = "80%";
  }

  function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
  }
</script>

</body>
</html>