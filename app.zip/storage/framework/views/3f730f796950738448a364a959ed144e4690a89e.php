<?php $__env->startSection('content'); ?>

  <!-- single offer type 1 -->

  <section class="gut mt-6">
    <div class="container-fluid webmag">
      <div class="row">
      
        <!-- right side content -->
        <div class="col-12 col-md-7">
          <div class="row mb-3">
            <div class="col-12 px-0">
              <div class="entervas-konko3">

                  <?php  
                    $id = $offer[0]->id;
                    $checkFavourite = false;
                    $image = "images/".$offer[0]->image;
                   ?>
				       	<img src="<?php echo e(asset($image)); ?>" alt="" class="vasimg">

                <div class="overlay-light-black"></div>
                <div class="text-contain">
                  <ul class="list-inline ">
                   <!--  <li class="list-inline-item py-1  wc "> <img src="img/pizzahut.jpg" alt="" class="off_brand_logo"></li> -->
                    
                  </ul>
                </div>
              </div>
            </div>
          </div>

          <div class="row px-3">
            <div class="col-10">
              <h5 class="mb-0 wc"><?php echo e(ucwords($offer[0]->title)); ?></h5>
              <small class="wc">Expires <?php echo e($offer[0]->end_date); ?></small>
            </div>
            <div class="col-2">
              <a onclick="myFavourite(<?php echo e($id); ?>)" id="<?php echo e($id); ?>">
                  <?php $__currentLoopData = $favourites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $favourite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
                  <?php if($favourite['offer_id'] == $id &&  $favourite['member_id'] == auth()->user()->id ): ?>
                  <?php $checkFavourite = true;  ?>
                  <i class="fa fa-heart fa-2x wc" aria-hidden="true"></i>
                  <?php endif; ?>
    
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php if($checkFavourite == false): ?>
                  <i class="fa fa-heart-o fa-2x wc" aria-hidden="true"></i>  
                  <?php endif; ?>
                
              </a></div>
          </div>
          <hr>

  
          <div class="row px-3">
           <div class="col-12"> 
             <p class="wc"><?php echo e(ucfirst($offer[0]->details)); ?></p>
           </div>
         </div>
         <hr>


         <!-- <div class="row px-3 mb-5">
           <div class="col-12">
            <p class="wc">imply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
           </div>
         </div> -->
       </div>
       <!-- right side content -->

       <!-- left side content -->
       <div class="col-12 col-md-5">
        <div class="row">
            <?php 
            foreach ($locations as $key => $row) {
              if($row['id'] == $offer[0]->location){
                 $latitude = $row['latitude'];
                 $longitude = $row['long'];
              }
              # code...
            }
    
            ?>
    
      <div class="col-12 px-0 pl-md-4" id="mapholder">
       

    
      
    </div>
    <input type="hidden"  id="latitude" value="<?php echo e($latitude); ?>">
     <input type ="hidden" id="longititude" value="<?php echo e($longitude); ?>">
        </div>

      <div class="row mb-5">
       <div class="col-12 text-center px-0 pl-md-4 my-5">
        <button type="button" onclick="getLocation()" class="btn btn-jam btn-lg btn-block">Redeem</button>
      </div>
    </div>
      </div>
      <!-- left side content -->
    </div>
  </div>

</section>

<!-- single offer type 1 -->



<!-- related offers  visible on pc only -->
<section  cclass="px-md-5 my-5 ">
  <div class="container-fluid2  d-none d-lg-block">
    <div class="row"> 
      <div class="col-12">
        <h4 class="wc mb-3">Offer you might be intrested </h4>
      </div>
      <div class="col-12">
         <div class="owl-carousel owl-hit owl-theme">
        <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php 
          $image = "images/".$row['image']; 
          ?>
        <div class="item">
            <div class="entervas-konko2">

           <img src="<?php echo e(asset($image)); ?>" alt="" class="vasimg">

          <div class="overlay-light-black"></div>
          <div class="text-contain">
            <div class="row ">
              <div class="col-10">
                <a href="/offers/<?php echo e($row->slug); ?>">
                 <h5 class="mb-0 wc"><?php echo e(ucwords($row->title)); ?></h5>
                 <small class="wc">Expires <?php echo e($row->end_date); ?></small>
               </a>
             </div>
             <div class="col-2">
                <a onclick="myFavourite(<?php echo e($row->id); ?>)" id="<?php echo e($row->id); ?>">
                    <?php $__currentLoopData = $favourites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $favourite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
                    <?php if($favourite['offer_id'] == $row->id &&  $favourite['member_id'] == auth()->user()->id ): ?>
                    <?php $checkFavourite = true;  ?>
                    <i class="fa fa-heart fa-2x wc" aria-hidden="true"></i>
                    <?php endif; ?>
      
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if($checkFavourite == false): ?>
                    <i class="fa fa-heart-o fa-2x wc" aria-hidden="true"></i>  
                    <?php endif; ?>
                  
                </a>
               
            </div>
           </div>
         </div>
       </div>
       <a href="/offers/<?php echo e($row->slug); ?>">
       <div class="card-body2">
        <p><?php echo e(ucfirst($row->details)); ?></p>
      </div>
      </a>
     </div>

     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
      </div>
    </div>
  </div>
</section>
<!-- related offers  visible on pc only -->

<script>
    //var x = document.getElementById("demo");

    var latitude = document.getElementById("latitude").value;
    var longititude = document.getElementById("longititude").value;
    
    function getLocation() {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition);
      } else { 
        x.innerHTML = "Geolocation is not supported by this browser.";

       // x.innerHTML = "Geolocation is not supported by this browser.";
      }
    }
    
    function showPosition(position) {



     // x.innerHTML = "Latitude: " + position.coords.latitude + 
     // "<br>Longitude: " + position.coords.longitude;

    //  var vendor_id = $('#vendor').val();

      // var formData = new FormData();
      //  formData.append('latitude', position.coords.latitude);
      //  formData.append('longitude', position.coords.longitude);

      //  $.ajaxSetup({
      //   headers: {
      //      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      //    }
      //   });

      //   $.ajax({
      //      method: 'POST',
      //      url: '/searchlocation',
      //      data:formData,
      //      cache:false,
      //      contentType: false,
      //      processData: false,
      //      success: function(data) {
             

      //      }
      //     });
      alert(latitude+"  | "+longititude);
      console.log(position.coords.latitude+" | "+position.coords.longitude);

      if(latitude == position.coords.latitude && longititude == position.coords.longitude){
         
        window.location.replace("/confirm-redeemed");

      }else{
      
        swal( "Ooops", "You are not in the offer zone.Please try again", "error");
      }

      // alert("Latitude: " + position.coords.latitude + 
      // "<br>Longitude: " + position.coords.longitude);
    }



    function showMap() {
      
      var latitude = document.getElementById("latitude").value;
      var longititude = document.getElementById("longititude").value;
      var latlon = latitude + "," + longititude;

    // var latlon = position.coords.latitude + "," + position.coords.longitude;
     var img_url = "https://maps.googleapis.com/maps/api/staticmap?center="+latlon+"&zoom=14&size=400x300&sensor=false&key=AIzaSyAmPOau9qDTSm4OD7X52R0Ab5CA23TdAfY";
    document.getElementById("mapholder").innerHTML = "<img src='"+img_url+"'>";
    }


    document.getElementById("mapholder").onload = showMap();
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front_layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>