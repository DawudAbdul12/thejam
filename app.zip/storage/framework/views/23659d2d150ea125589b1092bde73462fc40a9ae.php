<?php $__env->startSection('content'); ?>
<div class="m-content">
 <div class="row">
   


    <div class="col-md-12">


      <div class="m-alert m-alert--icon m-alert--air m-alert--square alert alert-dismissible m--margin-bottom-30" role="alert">
	<div class="m-alert__icon">
		<i class="flaticon-exclamation m--font-brand"></i>
	</div>
	<div class="m-alert__text">
		Lorem ipsum is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups
	</div>
   </div>
  



   <div class="m-portlet m-portlet--mobile">
    <div class="m-portlet__head">
		<div class="m-portlet__head-caption">
			<div class="m-portlet__head-title">
				<h3 class="m-portlet__head-text">
					All offers
				</h3>
			</div>
		</div>
		<div class="m-portlet__head-tools">
			<ul class="m-portlet__nav">
				<li class="m-portlet__nav-item">
					<a href="offer/create" class="btn btn-primary m-btn m-btn--custom m-btn--icon m-btn--air">
						<span>
							<i class="la la-plus"></i>
							<span>Add New Offer</span>
						</span>
					</a>
				</li>
				
			</ul>
		</div>
	</div>
	<div class="m-portlet__body">
		<!--begin: Datatable -->
		<table class="table table-striped- table-bordered table-hover table-checkable" id="m_table_1">
								<thead>
			  						  <tr>
				  									<th> ID</th>
													<th>Image</th>
				  									<th> Info</th>
				  									<th>Offer Usage</th>
				  									<th>Rate</th>
				  									<th>Status</th>
				  									<th>Date</th>
				  									<th>Actions</th>
				  						</tr>
						       </thead>
			
						<tbody>
				<?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				<tr>
								<td><?php echo e($row['id']); ?></td>
								<td><img src="images/<?php echo e($row['image']); ?>" style="height:50px;width:50px"> </td>
								<td>
								Title :<?php echo e($row['title']); ?> <br>
								Slug :<?php echo e($row['slug']); ?> <br>
								Vendor :<?php echo e($row['vendor_id']); ?> <br/>
								Category :<?php echo e($row['category_id']); ?>

								</td>
								<td>
								Maximum Usage :<?php echo e($row['maximum_use']); ?> <br>
								Start Time :<?php echo e($row['start_time']); ?> <br>
							    End Time :<?php echo e($row['end_time']); ?> <br>
								Start Date :<?php echo e($row['start_date']); ?> <br>
								End Date :<?php echo e($row['end_date']); ?>

								</td>
								<td><?php echo e($row['rate']); ?></td>
								<td><?php echo e($row['status']); ?></td>
								<td><?php echo e($row['created_at']); ?></td>
								<td><a href="offer/<?php echo e($row['id']); ?>/edit">Edit</a></td>
								
				</tr>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								
					</tbody>
			
					</table>
	</div>
</div>


      </div>   <!-- End of md 7 -->


   </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>