<?php $__env->startSection('content'); ?>
  
 <?php echo $__env->make('inc.profile_banner', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <!-- main content -->
  <section class="my-5">
    <div class="container">
      <div class="row">
      
      <?php echo $__env->make('inc.profile_side_bar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <div class="col-12 col-md-9">
        <div class="row pt-4">

          <div class="col-12 pl-md-5">
            <h3 class="wc mb-5"> Profile</h3>
            <?php echo $__env->make('message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <form action="/editprofile" method="POST" >
              <?php echo csrf_field(); ?>
             <div class="form-row">
              <div class="form-group col-12 col-md-6 ">
              <input type="text" class="form-control form-controltino" name="fname" placeholder="Firstname" value="<?php echo e(ucwords(auth()->user()->fname)); ?>">
              </div>

              <div class="form-group col-12 col-md-6 ">
                <input type="text" class="form-control form-controltino" name="lname" placeholder="Lastname"  value="<?php echo e(ucwords(auth()->user()->sname)); ?>">
              </div>


              <div class="form-group col-12 col-md-6">
                <input type="email" class="form-control form-controltino" name="email" placeholder="Your Email" value="<?php echo e(ucwords(auth()->user()->email)); ?>">
              </div>



              <div class="form-group col-12 col-md-6">
                <input type="text" class="form-control form-controltino" name="pnumber" placeholder="Number" value="<?php echo e(ucwords(auth()->user()->phone_number)); ?>">
              </div>

              <div class="form-group col-12 col-md-6">
                <input type="date" class="form-control form-controltino" name="dob" placeholder="DOB" value="<?php echo e(ucwords(auth()->user()->dob)); ?>">
              </div>



              <div class="form-group col-12 col-md-6">
                <input type="text" class="form-control form-controltino" id="subject" placeholder="Joined on" value="<?php echo e(ucwords(auth()->user()->created_at)); ?>">
              </div>



              <div class="form-group col-12">
                <textarea class="form-control form-controltino input-lg" rows="4" placeholder="Bio " name="details" ><?php echo e(ucfirst(auth()->user()->details)); ?></textarea>
              </div>
            </div>
         
          <div class="col-12 text-center px-0 py-5">
            <button type="submit"  class="btn btn-jam btn-lg btn-block">Update Profile</button>
          </div>
        </div>
      </form>

      </div>
    </div>



  </div>
</div>
</section>
<!-- main content -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('front_layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>