  <?php if(isset($success)): ?>
    <div class="alert alert-success alert-dismissible">
        <a href="#" class="close" data-dismiss="alert" aria-label="close"></a>
        <strong><?php echo e($success); ?></strong> 
    </div>
<?php elseif(isset($error)): ?>
    <div class="alert alert-danger alert-dismissible">
        <a href="#" class="close" data-dismiss="alert" aria-label="close"></a>
        <strong><?php echo e($error); ?></strong> 
    </div>
<?php endif; ?>