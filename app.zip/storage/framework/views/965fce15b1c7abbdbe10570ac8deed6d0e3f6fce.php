  
        <div class="col-12 col-md-3">
                <div class="">
                    <?php  $image = "profile_pic/".auth()->user()->profile_pic;  ?>
                <img src="<?php echo e(asset($image)); ?>" alt="<?php echo e(auth()->user()->fname); ?>" width="120" class="rounded-circle border ">
                 <h3 class="wc"><?php echo e(auth()->user()->fname." " .auth()->user()->sname); ?> </h3>
               </div>
               <div class="pt-5">
                 <div class="list-group">

                   <a href="/profile" class="list-group-item list-group-item-action <?php echo e(Request::is('profile') ? 'active' : null); ?>">MY PROFILE</a>
                   <a href="/redeem-history" class="list-group-item list-group-item-action <?php echo e(Request::is('redeem-history') ? 'active' : null); ?>">OFFER HISTORY</a>
                   <a href="/social-media" class="list-group-item list-group-item-action <?php echo e(Request::is('social-media') ? 'active' : null); ?>">SOCIAL MEDIA</a>
                   <a href="/change-password" class="list-group-item list-group-item-action <?php echo e(Request::is('change-password') ? 'active' : null); ?> ">CHANGE PASSWORD</a>
       

                 </div>
               </div>
             </div>