<?php $__env->startSection('content'); ?>

  <!-- header image -->
  
  <?php echo $__env->make('inc.profile_banner', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- header image -->



  <!-- main content -->
  <section class="my-5">
    <div class="container">
      <div class="row">
      
      <?php echo $__env->make('inc.profile_side_bar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


      <div class="col-12 col-md-9">
        <div class="row pt-4">

          <div class="col-12 pl-md-5">
            <h3 class="wc mb-5">Change Password</h3>
            <?php echo $__env->make('message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <form action="/editpassword" method="POST">
              <?php echo csrf_field(); ?>
             <div class="form-row">
              <div class="form-group col-12 col-md-6 ">
                <input type="password" class="form-control form-controltino" name="password" placeholder="New Password" required>
              </div>

                <div class="form-group col-12 col-md-6 ">
                <input type="password" class="form-control form-controltino" name="cpassword" placeholder="Confirm Password" required>
              </div>

          <div class="col-12 text-center px-0 py-5">
            <button type="submit" class="btn btn-jam btn-lg btn-block">Update Password</button>
          </div>
        </form>

        </div>

      </div>
    </div>



  </div>
</div>
</section>
<!-- main content -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('front_layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>