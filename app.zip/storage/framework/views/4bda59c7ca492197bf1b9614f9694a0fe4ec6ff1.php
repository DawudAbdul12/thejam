<?php $__env->startSection('content'); ?>

<section class="mt-7 jammasback">
  <div class="container pt-5">
    <div  class="row ">
      <div class="col-8 mx-auto centerit text-center">
        <img src="img/correct.png" class="img-fulid offericon" width="80">
      </div>
    </div>

    <div class="row">
      <div class="col-12 text-center mt-5">
        <h4 class="jamcol">Confirm Redeemed</h4>
        
      </div>
    </div>


    <div class="row">
      <div class="col-12">
          <div class="col-12 text-center px-0 pl-md-4 my-5">
              <a  href="/offer-redeemed" type="button"  class="btn btn-jam btn-lg btn-block">Confirm</a>
          </div>

       
      </div>
    </div>


  </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front_layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>