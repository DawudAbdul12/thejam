<?php $__env->startSection('content'); ?>

  <!--  Your Favourite -->
  
<!--  Your Favourite -->


  <!-- all offers -->
  <section class="mt-7 my-md-5">
    <div class="container-fluid container-fluid2">
      <div class="row mb-3">

  <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
      <?php $__currentLoopData = $favourites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $favourite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($favourite['offer_id'] == $row->id &&  $favourite['member_id'] == auth()->user()->id ): ?>
        
      <div class="col-12 col-md-4 px-0 px-md-3 mb-4">
          <?php 
          $image = "images/".$row['image']; 
          ?>

          <div class="entervas-konko2">
            <img src="<?php echo e(asset($image)); ?>" alt="" class="vasimg">
            <div class="overlay-light-black"></div>
            <div class="text-contain">
              <div class="row ">
                <div class="col-12 text-right">
                  <a href="offers/<?php echo e($row->slug); ?>">
                   <h4 class="mb-0 wc"><?php echo e(ucwords($row->title)); ?></h4>
                   <small class="wc">Expires <?php echo e($row->end_date); ?></small>
                 </a>
               </div>
             </div>
           </div>
         </div>
         <a href="offers/<?php echo e($row->slug); ?>">
         <div class="card-body3">
            
            <p><?php echo e(ucfirst($row->details)); ?></p>
        </div>
        </a>
      </div>

          <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>

  </div>
</section>
<!-- all offers -->


<!-- load More -->

<!-- load More -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front_layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>