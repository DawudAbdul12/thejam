<?php $__env->startSection('content'); ?>
<div class="m-content">
		<?php 
		$totalVendors = count($vendors); 
		?>

 <div class="row">
  <div class="col-md-12">
	    <!--begin:: Widgets/Product Sales-->
<div class="m-portlet m-portlet--bordered-semi m-portlet--space m-portlet--full-height ">
	
	<div class="m-portlet__body">
		<div class="m-widget25">
			<span class="m-widget25__price m--font-brand"><?php echo e($totalVendors); ?> Vendors</span>
			
		<div class="row">
            <div class="col-md-4">
				<a href="vendors/status/approved" class="m-widget25__progress">
					<span class="m-widget25__progress-number">
					<?php echo e(number_format((count($approved)/$totalVendors)*100,2)); ?>%
				    </span>				         
					<div class="m--space-10"></div>
					<div class="progress m-progress--sm">
						<div class="progress-bar m--bg-success" role="progressbar" style="width: <?php echo e(number_format((count($approved)/$totalVendors)*100,2)); ?>%;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
					</div>						 
					<span class="m-widget25__progress-sub">
						Approved Vendor(s)
					</span>
               </a>
			</div>
	
			<div class="col-md-4">
			<a href="vendors/status/pending" class="m-widget25__progress">
					<span class="m-widget25__progress-number">
					<?php echo e(number_format((count($pending)/$totalVendors)*100,2)); ?>%
				    </span>				         
					<div class="m--space-10"></div>
					<div class="progress m-progress--sm">
						<div class="progress-bar m--bg-warning" role="progressbar" style="width: <?php echo e(number_format((count($pending)/$totalVendors)*100,2)); ?>%;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
					</div>						 
					<span class="m-widget25__progress-sub">
						Pending Vendor(s)
					</span>
           </a>
			</div>	

			<div class="col-md-4">
			<a href="vendors/status/blocked" class="m-widget25__progress" >
					<span class="m-widget25__progress-number">
					<?php echo e(number_format((count($blocked)/$totalVendors)*100,2)); ?>%
				    </span>				         
					<div class="m--space-10"></div>
					<div class="progress m-progress--sm">
						<div class="progress-bar m--bg-danger" role="progressbar" style="width: <?php echo e(number_format((count($blocked)/$totalVendors)*100,2)); ?>%;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
					</div>						 
					<span class="m-widget25__progress-sub">
						Blocked Vendor(s)
					</span>
             </a>
			</div>
		</div>	
					
		</div>			 
	</div>
</div>
<!--end:: Widgets/Product Sales-->
</div>

    <div class="col-md-12">

   <div class="m-portlet m-portlet--mobile">
    <div class="m-portlet__head">
		<div class="m-portlet__head-caption">
			<div class="m-portlet__head-title">
				<h3 class="m-portlet__head-text">
					All Vendors
				</h3>
			</div>
		</div>
		<div class="m-portlet__head-tools">
			<ul class="m-portlet__nav">
				<li class="m-portlet__nav-item">
					<a href="/vendor/create" class="btn btn-primary m-btn m-btn--custom m-btn--icon m-btn--air">
						<span>
							<i class="la la-plus"></i>
							<span>Add New Vendor</span>
						</span>
					</a>
				</li>
				
			</ul>
		</div>
	</div>
	<div class="m-portlet__body">
		<!--begin: Datatable -->
		<table class="table table-striped- table-bordered table-hover table-checkable" id="m_table_1">
								<thead>
			  						  <tr>
				  									<th> ID</th>
													<th>Image</th>
				  									<th>Account Details</th>
				  									<th>About Your Business</th>
				  									<th>Accout Setup</th>
				  									<th>Date</th>
				  									<th>Actions</th>
				  						</tr>
						       </thead>
			
						<tbody>
				<?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				<tr>
								<td><?php echo e($row['id']); ?></td>
								<?php  $image = "images/".$row['image'];  ?>
						       <td><img src="<?php echo e(asset($image)); ?>" style="height:50px;width:50px"> </td>
								<!-- <td><img src="images/<?php echo e($row['image']); ?>" style="height:50px;width:50px"> </td> -->

								<td>
									Fullname :<?php echo e($row['fname']." ".$row['lname']); ?> <br>
									Email :<?php echo e($row['p_email']); ?> <br>
									Phone number :<?php echo e($row['p_phone']); ?> <br>
								</td>
								
								<td>
									Name of business:<?php echo e($row['name_business']); ?><br/>
									Registered company entitie:<?php echo e($row['registered_company_entitie']); ?><br/>
									Business email:<?php echo e($row['business_email']); ?><br/>
									Registered address:<?php echo e($row['registered_address']); ?>

								</td>


								<td>

								<?php echo e($row['status']); ?>



								</td>
								
								<td><?php echo e($row['created_at']); ?></td>
								<td><a href="/vendor/<?php echo e($row['id']); ?>/edit">Edit</a><br/>
								<a href="/vendorinfo/<?php echo e($row['id']); ?>">View</a>

							    </td>
								
				</tr>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								
					</tbody>
			
					</table>
	</div>
</div>


      </div>   <!-- End of md 7 -->


   </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>