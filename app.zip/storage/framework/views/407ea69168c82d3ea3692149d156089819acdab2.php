<!doctype html>
<html lang="en">
<head>
  <title>The JAM</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="author" content="">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

  <!-- include navigation -->
  <?php echo $__env->make('inc.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php //require_once("includes/navigation.php");?>
  <!-- include navigation -->

  <?php echo e(Form::hidden('member_id',auth()->user()->id,['id'=>'member_id'])); ?>


   <!-- CONTENT -->
    <?php echo $__env->yieldContent('content'); ?>

    <!-- CONTENT -->



<!-- footer includes -->
<?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php //require_once("includes/footer.php");?>
<!-- footer includes -->

<script>
  function openNav() {
    document.getElementById("mySidenav").style.width = "80%";
  }

  function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
  }
</script>

</body>
</html>