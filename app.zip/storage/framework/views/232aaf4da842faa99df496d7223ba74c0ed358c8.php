<?php $__env->startSection('content'); ?>

  <!-- header image -->
 
 <?php echo $__env->make('inc.profile_banner', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- header image -->

  <!-- main content -->
  <section class="my-5">
    <div class="container">
      <div class="row">

    
    <?php echo $__env->make('inc.profile_side_bar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <div class="col-12 col-md-9">
        <div class="row pt-4">

          <div class="col-12 pl-md-5">
            <h3 class="wc mb-5">Social Media Following</h3>

            <div class="row">


              <div class="col-12 col-md-4">
                 
                <button type="button" class="btn btn-primary "><span class="px-3"><i class="fa fa-facebook " aria-hidden="true"></i></span>Facebook Connect</button>
                <p class="wc mt-3">5K <span>Followers</span></p>
              </div>
              <div class="col-12 col-md-4">
                  <button type="button" class="btn btn-twitter"><span class="px-3"><i class="fa fa-twitter " aria-hidden="true"></i></span>Twitter Connect</button>
                <p class="wc mt-3">1K <span>Followers</span></p>
              </div>
              <div class="col-12 col-md-4">
                 <button type="button" class="btn btn-ig"><span class="px-3"><i class="fa fa-instagram " aria-hidden="true"></i></span>Instagram Connect</button>
                <p class="wc mt-3">10K <span>Followers</span></p>
              </div>


            </div>


          </div>

        </div>
      </div>



    </div>
  </div>
</section>
<!-- main content -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('front_layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>