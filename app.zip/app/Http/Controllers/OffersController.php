<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\offers_tb;
use App\vendor_tb;
use App\category_tb;
use DB;
class OffersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $offers = offers_tb::all();
        return view('admin.offers.all_offers')->with('offers', $offers);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $vendors = vendor_tb::all();
        $categories = category_tb::all();
        return view('admin.offers.add_offer')->with(['vendors' =>  $vendors,'categories' => $categories ] );
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try{
        //
        $offer = new offers_tb;
        $vendors = vendor_tb::all();
        $categories = category_tb::all();
        $rate =0.0;
        // $this->validate($request, [
        //     'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        // ]);
    
        if ($request->hasFile('image')) {
            
            $image = $request->file('image');
            $image_name = time().'.'.$image->getClientOriginalExtension();
            $destinationPath = public_path('/images');
            $image->move($destinationPath, $image_name);

            // $this->save();
            // return back()->with('success','Image Upload successfully');

        }else{
           $image_name = "";
        }

        $offer->title = $request->input('name');
        $offer->slug = $request->input('slug');
        $offer->vendor_id = $request->input('vendor');
        $offer->category_id = $request->input('category'); 
        $offer->rate = $rate;
        $offer->status = $request->input('status');
        $offer->maximum_use = $request->input('max_use');
        $offer->start_time = $request->input('start_time');
        $offer->end_time = $request->input('end_time');
        $offer->start_date = $request->input('start_date');
        $offer->end_date = $request->input('end_date');
        $offer->type= $request->input('type');
        $offer->details = $request->input('details');
        $offer->image = $image_name;
        $offer->featured= $request->input('featured');
        $offer->location = $request->input('location');
        // SAVE
        $offer->save();
        

     return view('admin.offers.add_offer')->with(['success' => 'You Have Added Offer Succefully .','vendors' =>  $vendors,'categories' => $categories]);
    } catch (\Exception $e) {
     //return $e->getMessage();
    return view('admin.offers.add_offer')->with(['error' => 'Offer Already Exist','vendors' =>  $vendors,'categories' => $categories]);
      // return view('admin.category.categories')->with(['categories' => $categories, 'success' => $e->getMessage()]); ;
    }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $vendors = vendor_tb::all();
        $categories = category_tb::all();
        $offer = offers_tb::find($id);
        return view('admin.offers.edit_offer')->with(['offer'=> $offer,'vendors' =>  $vendors,'categories' => $categories]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $vendors = vendor_tb::all();
        $categories = category_tb::all();
        $offer = offers_tb::find($id);
        return view('admin.offers.edit_offer')->with(['offer'=> $offer,'vendors' =>  $vendors,'categories' => $categories]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        try{
        //
        $offer = offers_tb::find($id);
        $vendors = vendor_tb::all();
        $categories = category_tb::all();
        // $this->validate($request, [
        //     'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        // ]);
    
        if ($request->hasFile('image')) {
            
            $image = $request->file('image');
            $image_name = time().'.'.$image->getClientOriginalExtension();
            $destinationPath = public_path('/images');
            $image->move($destinationPath, $image_name);
            $offer->image = $image_name;

            // $this->save();
            // return back()->with('success','Image Upload successfully');

        }else{
           $image_name = "";
        }

        $offer->title = $request->input('name');
        $offer->slug = $request->input('slug');
        $offer->vendor_id = $request->input('vendor');
        $offer->category_id = $request->input('category'); 
        $offer->status = $request->input('status');
        $offer->maximum_use = $request->input('max_use');
        $offer->start_time = $request->input('start_time');
        $offer->end_time = $request->input('end_time');
        $offer->start_date = $request->input('start_date');
        $offer->end_date = $request->input('end_date');
        $offer->type= $request->input('type');
        $offer->details = $request->input('details');
    
        // SAVE
        $offer->save();
        $offer = offers_tb::find($id);
       
    return view('admin.offers.edit_offer')->with(['success' => 'Updated Succefully .','offer'=> $offer,'vendors' =>  $vendors,'categories' => $categories]);
    } catch (\Exception $e) {
     return $e->getMessage();
     //return view('admin.offers.edit_offer')->with(['error' => 'Offer Already Exist','offer' => $offer,'vendors' =>  $vendors,'categories' => $categories]);
      // return view('admin.category.categories')->with(['categories' => $categories, 'success' => $e->getMessage()]); ;
    }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    
    //##############   FRONT END CONTROLLER ###################
    
    public function front_index()
    {
        $end_date = date("Y-m-d");
        //$vendors = vendor_tb::all();
        $approved = offers_tb::WHERE([
            ['status', '=', 'approved'],
            ['end_date', '>=', $end_date],
        ])->get();

        $featured = offers_tb::WHERE([
            ['status', '=', 'approved'],
            ['end_date', '>=', $end_date],
            ['featured', '=', 'Yes'],
        ])->orderBy('start_date', 'ASC')->take(3)->get();

        //$approved = vendor_tb::WHERE('status', 'approved')->get();
        // $pending = vendor_tb::WHERE('status', 'Pending')->get();
        // $blocked = vendor_tb::WHERE('status', 'Blocked')->get();
        return view('index')->with(['approved' => $approved, 'featured' => $featured]);
        
    }


    //############   SINGLE PAGE ##############################//
     
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show_single($slug)
    {
        //
        //$offer = offers_tb::find(1);
        $offer = offers_tb::WHERE('slug', $slug)->get();
        //return $offer;
        return view('offer_single')->with(['offer'=> $offer]);
    }

    //############   SINGLE PAGE ##############################//









    //###############   END OF FRONT CONTROLLER ###################
}
