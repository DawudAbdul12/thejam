<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BusLocation extends Model
{
    //
   // protected $fillable = array('bus_address', 'long','latitude','vendor_id');

   protected $guarded = [];
}
