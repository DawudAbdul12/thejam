<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VendorLocation extends Model
{
    //
}
