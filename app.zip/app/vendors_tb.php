<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class vendors_tb extends Model
{
    //
}
